import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { ApiService } from 'src/app/SERVICES/api.service';

@Component({
  selector: 'app-order',
  templateUrl: './order.component.html',
  styleUrls: ['./order.component.scss']
})
export class OrderComponent implements OnInit {

  
  orders:any=[];
  reasonReturn:boolean=true;
  @ViewChild('returnProduct') returnProduct!:ElementRef;

  reasonStatus:any;
  constructor(private _api:ApiService) { }

  ngOnInit(): void {
    this._api.getOrders().subscribe( res=>
      {
        this.orders=res;
      })
  }


  onReturn()
  {
    console.log( this.returnProduct.nativeElement.value);
    this.reasonStatus=this.returnProduct.nativeElement.value;
    alert(`Return request send successfully`)
    this.reasonReturn=false;
  }

}
